package com.isi.examen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParametrageApplication {
	public static void main(String[] args) {
		SpringApplication.run(ParametrageApplication.class, args);
	}
}